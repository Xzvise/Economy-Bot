module.exports = {
    prefix: "e!",
    admins: [
        "730045222427426817"
],
    debug: false,
    Channel: "907069273535545354"
};
